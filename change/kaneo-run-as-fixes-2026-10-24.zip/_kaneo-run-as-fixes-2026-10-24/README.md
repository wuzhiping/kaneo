# kaneo 补丁：run-as 的 3 处修正

- 基线：`kaneo/` HEAD = `8799003739ba "run-as"`（run-as 特性已提交）
- 导出时间：2026-10-24
- 范围：3 个文件的小修正（run-as 功能本体已在上一次提交里）

## 1. `apps/api/src/mcp/index.ts` —— run-as 改为按需加载

原先在模块顶层 `import { applyRunAs } from "../utils/run-as"`，而 `run-as.ts` 会经 `../utils/user-ban` 拉进 `../database`（drizzle + pg）。

`tests/api/mcp-internal-api-url.test.ts` 把 `../../apps/api/src/auth` 整个 mock 掉了，本来**不会**加载 database 模块；加上这条 eager import 后，database 被拖进 MCP 的 import 图，该测试文件的首个用例（内部就包含一次完整模块重载）耗时从 ~4.85s 涨到 ~5.15s，**顶破 5s 默认 timeout**。

改为在 API Key 分支里动态 import：

```ts
const { applyRunAs } = await import("../utils/run-as");
```

只有真正用 API Key 走 MCP 时才会加载，OAuth session 路径完全不受影响。

## 2. `apps/api/src/api-key-sign-in/index.ts` —— 修一个已存在的类型错误

`user.role` 在 better-auth 的 `User` 类型上不存在（`role` 是 Kaneo 自己加的字段）：

```ts
-          !hasInstanceAdminRole(user.role)
+          !hasInstanceAdminRole((user as { role?: string | null }).role)
```

修之前 `pnpm --filter @kaneo/api typecheck` 是**失败**的（TS2339），与 run-as 无关，但会卡住 CI。

## 3. `tests/api/mcp-internal-api-url.test.ts` —— 放宽首个用例的 timeout

该用例在测试体内做 `vi.resetModules()` + 完整 import MCP 模块图，本身就要 4.8~5.1s，5s 默认值是个硬币。显式给 15s（仓库已有同类写法，如 `tests/api/utils/sensitive-outbound.test.ts` 的 `30_000`）。

## 验证结果（本机）

| 检查 | 结果 |
| --- | --- |
| `pnpm --filter @kaneo/api typecheck` | ✅ exit 0 |
| `pnpm --filter @kaneo/api test` | 1 failed \| 157 passed (文件)；1 failed \| 1165 passed (用例) |
| 唯一失败 | `tests/api/github-integration/bounded-fetch.test.ts` → 满负载下 5s 超时；**单独跑 8/8 通过**，且与本次改动无代码路径交集（GitHub App auth 传输层） |
| `mcp-internal-api-url.test.ts` 单独跑 3 次 | ✅ 3/3 全过（修正前 3 次里有 1~2 次超时） |

## 应用

```bash
unzip kaneo-run-as-fixes-2026-10-24.zip -d /tmp/kf
cp -r /tmp/kf/. /path/to/kaneo/        # _kaneo-run-as-fixes-2026-10-24/ 可忽略
```

或：`git -C /path/to/kaneo apply /tmp/kf/_kaneo-run-as-fixes-2026-10-24/CHANGES.patch`

无 schema 变更、无迁移。